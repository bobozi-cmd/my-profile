#pragma once
#include "Foundation/Foundation.hpp"
#include "Metal/Metal.hpp"

class MetalAdder {
private:
  MTL::Device *_mDevice;
  // The compute pipeline generated from the compute kernel in the .metal shader
  // file.
  MTL::ComputePipelineState *_mAddFunctionPSO;

  // The command queue used to pass commands to the device.
  MTL::CommandQueue *_mCommandQueue;

  // Buffers to hold data.
  MTL::Buffer *_mBufferA;
  MTL::Buffer *_mBufferB;
  MTL::Buffer *_mBufferResult;

public:
  MetalAdder(MTL::Device *device);

  void prepareData();
  void sendComputeCommand();
  void encodeAddCommand(MTL::ComputeCommandEncoder *computeEncoder);
  void generateRandomFloatData(MTL::Buffer *buffer);
  void verifyResults();
};
