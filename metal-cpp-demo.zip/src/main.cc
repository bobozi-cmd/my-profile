#define NS_PRIVATE_IMPLEMENTATION
#define CA_PRIVATE_IMPLEMENTATION
#define MTL_PRIVATE_IMPLEMENTATION

#include "Foundation/Foundation.hpp"
#include "Metal/Metal.hpp"
#include "QuartzCore/QuartzCore.hpp"
#include <iostream>

#include "MetalAdder.hpp"

void add_arrays(const float *inA, const float *inB, float *result, int length) {
  for (int index = 0; index < length; index++) {
    result[index] = inA[index] + inB[index];
  }
}

int main(int argc, const char *argv[]) {
  // Get default GPU
  MTL::Device *device = MTL::CreateSystemDefaultDevice();
  std::cout << "Device -> \nname: " << device->name()->utf8String()
            << "; \narchitecture: "
            << device->architecture()->name()->utf8String()
            << "; \ndescription: " << device->description()->utf8String()
            << std::endl;

  // Init Metal object
  MetalAdder *adder = new MetalAdder(device);
  adder->prepareData();
  adder->sendComputeCommand();

  // Release resource
  device->release();

  return 0;
}