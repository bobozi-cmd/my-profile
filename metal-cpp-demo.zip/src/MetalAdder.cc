#include "MetalAdder.hpp"
#include "Foundation/NSString.hpp"
#include "Foundation/NSTypes.hpp"
#include "Metal/MTLDevice.hpp"
#include "Metal/MTLLibrary.hpp"
#include "Metal/MTLTypes.hpp"
#include <cassert>
#include <cstdlib>
#include <iostream>

const unsigned int arrayLength = 1 << 24;
const unsigned int bufferSize = arrayLength * sizeof(float);

MetalAdder::MetalAdder(MTL::Device *device) {
  _mDevice = device;
  NS::Error *error = nullptr;

  // Load the shader files with a .metal file extension in the project
  MTL::Library *defaultLibrary = _mDevice->newLibrary(
      NS::String::string("./build/bin/add.metallib", NS::UTF8StringEncoding),
      &error);

  if (defaultLibrary == nullptr) {
    std::cout << "Failed to find the default library." << std::endl;
    assert(defaultLibrary != nullptr);
  }
  MTL::Function *addFunction = defaultLibrary->newFunction(
      NS::String::string("add_arrays", NS::UTF8StringEncoding));
  if (addFunction == nullptr) {
    std::cout << "Failed to find the adder function." << std::endl;
    assert(addFunction != nullptr);
  }

  // Create a compute pipeline state object.
  _mAddFunctionPSO = _mDevice->newComputePipelineState(addFunction, &error);
  if (_mAddFunctionPSO == nullptr) {
    // If the Metal API validation is enabled, you can find out more information
    // about what went wrong.  (Metal API validation is enabled by default when
    // a debug build is run from Xcode)
    std::cout << "Failed to created pipeline state object, error "
              << error->description()->utf8String() << std::endl;
    assert(_mAddFunctionPSO != nullptr);
  }

  _mCommandQueue = _mDevice->newCommandQueue();
  if (_mCommandQueue == nullptr) {
    std::cout << "Failed to find the command queue." << std::endl;
    assert(_mCommandQueue != nullptr);
  }
}

void MetalAdder::prepareData() {
  // Allocate three buffers to hold our initial data and the result.
  _mBufferA = _mDevice->newBuffer(bufferSize, MTL::ResourceStorageModeShared);
  _mBufferB = _mDevice->newBuffer(bufferSize, MTL::ResourceStorageModeShared);
  _mBufferResult =
      _mDevice->newBuffer(bufferSize, MTL::ResourceStorageModeShared);

  generateRandomFloatData(_mBufferA);
  generateRandomFloatData(_mBufferB);
}

void MetalAdder::sendComputeCommand() {
  // Create a command buffer to hold commands.
  MTL::CommandBuffer *commandBuffer = _mCommandQueue->commandBuffer();
  assert(commandBuffer != nullptr);

  // Start a compute pass.
  MTL::ComputeCommandEncoder *computeEncoder =
      commandBuffer->computeCommandEncoder();
  assert(computeEncoder != nullptr);

  encodeAddCommand(computeEncoder);

  // End the compute pass.
  computeEncoder->endEncoding();

  // Execute the command.
  commandBuffer->commit();

  // Normally, you want to do other work in your app while the GPU is running,
  // but in this example, the code simply blocks until the calculation is
  // complete.
  commandBuffer->waitUntilCompleted();

  verifyResults();
}

void MetalAdder::encodeAddCommand(MTL::ComputeCommandEncoder *computeEncoder) {
  // Encode the pipeline state object and its parameters.
  computeEncoder->setComputePipelineState(_mAddFunctionPSO);
  computeEncoder->setBuffer(_mBufferA, 0, 0);
  computeEncoder->setBuffer(_mBufferB, 0, 1);
  computeEncoder->setBuffer(_mBufferResult, 0, 2);

  MTL::Size gridSize = MTL::Size::Make(arrayLength, 1, 1);

  // Calculate a threadgroup size.
  NS::UInteger threadGroupSize =
      _mAddFunctionPSO->maxTotalThreadsPerThreadgroup();
  if (threadGroupSize > arrayLength) {
    threadGroupSize = arrayLength;
  }

  MTL::Size threadgroupSize = MTL::Size::Make(threadGroupSize, 1, 1);

  // Encode the compute command.
  computeEncoder->dispatchThreads(gridSize, threadgroupSize);
}

void MetalAdder::generateRandomFloatData(MTL::Buffer *buffer) {
  float *dataPtr = (float *)buffer->contents();

  for (unsigned long index = 0; index < arrayLength; index++) {
    dataPtr[index] = (float)rand() / (float)(RAND_MAX);
  }
}

void MetalAdder::verifyResults() {
  float *a = (float *)_mBufferA->contents();
  float *b = (float *)_mBufferB->contents();
  float *result = (float *)_mBufferResult->contents();

  for (unsigned long index = 0; index < arrayLength; index++) {
    if (result[index] != (a[index] + b[index])) {
      std::cout << "Compute ERROR: index=" << index
                << " result=" << result[index] << " vs " << a[index] + b[index]
                << "=a+b" << std::endl;
      assert(result[index] == (a[index] + b[index]));
    }
  }
  std::cout << "Compute results as expected" << std::endl;
}